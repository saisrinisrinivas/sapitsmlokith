import React from 'react'


const ContextProvider = () => {
  return (
    <div>ContextProvider</div>
  )
}

export default ContextProvider